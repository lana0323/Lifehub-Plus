"""Authoring only: does not import or execute the application or model."""
import json
import random
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/lifehub-unseen-holdout-v5'
OUT.mkdir(parents=True, exist_ok=True)
cases = []
group = language = None
number = 0

def section(g, lang):
    global group, language, number
    group, language, number = g, lang, 0

def add(text, tag, title=None, *, date=None, priority=None, time=None,
        amount=None, kind=None, category=None, account=None, clarify=False,
        now='2026-11-18T12:00:00+00:00', zone=None):
    global number
    number += 1
    expected = {'status':'clarification' if clarify else 'draft', 'module':None if clarify else group}
    if not clarify:
        if group != 'health':
            expected['title'] = {'containsAny': title if isinstance(title,list) else [title]}
            expected['date'] = date
        if group == 'memo': expected['priority'] = priority
        if group == 'schedule': expected['time'] = time
        if group == 'finance': expected.update(amount=amount,kind=kind,category=category,account=account)
    required = [] if clarify else {'memo':['title'], 'schedule':['title','date'],
        'finance':['title','amount','kind','category','account','date'], 'health':[]}[group]
    cases.append(dict(id=f'U5-{language.upper()}-{group.upper()}-{number:02}', group=group,language=language,
        text=text,timezone=zone or ('Asia/Shanghai' if language=='zh' else 'America/Los_Angeles'),
        now=now,module='auto',expected=expected,requiredFields=required,tags=[tag]))

section('memo','zh')
add('备忘录加一项：今天把打印机墨盒换掉，普通优先级。','ordinary_complete','墨盒',date='2026-11-18',priority='normal')
add('想起来一件待办，给旧电脑里的毕业照片做备份。','missing_optional','照片')
add('周五之前交停车证申请，这个很重要，放入待办。','bare_weekday','停车证',date='2026-11-20',priority='important')
add('在 memo 记一下：11月30日之前退还实验室门禁卡。','mixed_language','门禁卡',date='2026-11-30')
add('买一盒彩色回形针，最近有空再办，优先级低，存成备忘。','vague_date','回形针',priority='normal')
add('不是让你现在发邮件，是把“给导师发送修改后的摘要”记到待办。','negated_execution','摘要')
add('备忘：两天后清洗空气净化器滤网，紧急。','written_relative','滤网',date='2026-11-20',priority='urgent')
add('帮我存个待办：续借图书馆那本《Tomorrow》，没有截止时间。','quoted_date','续借')
add('往备忘录放一条，核队一下志愿者名单，重要。','typo','名单',priority='important')
add('建一个任务，明天把阳台的花盆搬进屋；不要设成高优先级，普通就行。','negated_priority','花盆',date='2026-11-19',priority='normal')
add('新建备忘：明天整理摄影比赛报名材料。','timezone_year_boundary','摄影',date='2027-01-02',now='2026-12-31T16:30:00+00:00')
add('备忘标题用“收拾针线盒”，周末或者下周再弄，时间还没定。','ambiguous_date','针线盒')
add('把我之前那个“寄还钥匙”的待办直接标成完成。','unsupported_mutation',clarify=True)
add('新建两个待办：擦自行车链条，另外预约眼镜维修。','multiple_records',clarify=True)
add('把我最紧急的三条待办找出来给我看。','unsupported_query',clarify=True)

section('memo','en')
add('Add a normal-priority to-do to label the freezer containers today.','ordinary_complete',['freezer','containers'],date='2026-11-18',priority='normal')
add('A note to myself: digitize Grandma’s handwritten recipe cards.','missing_optional',['recipe','Grandma'])
add('Put renewing the bicycle locker permit on my task list for next Monday. High priority.','next_weekday',['locker','permit'],date='2026-11-23',priority='important')
add('Memo please: check the tent poles before November 24.','explicit_month_day',['tent','poles'],date='2026-11-24')
add('To-do: mend the sleeve on my blue cardigan sometime soon. Low priority.','vague_date',['cardigan','sleeve'],priority='normal')
add('Don’t delete any files. Add a task called delete duplicate microscope images.','negated_execution',['microscope','duplicate'])
add('Put cleaning the aquarium filter on my list in 3 days; urgent.','numeric_relative',['aquarium','filter'],date='2026-11-21',priority='urgent')
add('Save a memo to read the novel named "Friday". No deadline for this.','quoted_date',['novel','Friday'])
add('Remeber to re-order hearing aid batteries; add that to my to-do list.','typo',['batteries','hearing aid'])
add('Create a memo: check the wheelchair tyre pressure tomorrow, normal rather than high priority.','negated_priority',['wheelchair','tyre','tire'],date='2026-11-19',priority='normal')
add('Task for tomorrow: pack the pottery pieces for storage.','timezone_date_boundary',['pottery'],date='2026-11-18',now='2026-11-18T06:30:00+00:00')
add('A task: return the borrowed projector on Saturday or Sunday; I have not chosen a day.','ambiguous_date',['projector'],date=None)
add('Move the due date of my existing passport task to the 28th.','unsupported_mutation',clarify=True)
add('Make a memo to collect the dry cleaning, and also record 46 yuan spent on dinner.','cross_module',clarify=True)
add('How many of my tasks are still unfinished?','unsupported_query',clarify=True)

section('finance','zh')
add('今天早餐豆浆和烧饼一共花了14.50元，支付宝付的，记一笔餐饮支出。','ordinary_complete',['豆浆','烧饼','早餐'],date='2026-11-18',amount='14.50',kind='expense',category='Food & Drinks',account='Alipay')
add('昨天坐轮渡花了6元现金，记到交通费。','relative_past',['轮渡'],date='2026-11-17',amount='6',kind='expense',category='Transport',account='Cash')
add('记账：2026年11月16日，工资到账8600元，银行卡收入。','ordinary_income',['工资'],date='2026-11-16',amount='8600',kind='income',category='Salary',account='Bank Card')
add('今天网上买了卷尺，微信支付23元，分类购物，帮我记一下。','ordinary_complete',['卷尺'],date='2026-11-18',amount='23',kind='expense',category='Shopping',account='WeChat')
add('记今天的电费支出，银行卡扣款，金额等账单来了再填。','missing_amount',['电费'],date='2026-11-18',amount=None,kind='expense',category='Bills',account='Bank Card')
add('今天买了电影票，支出39元，具体用哪个账户付的记不清了。','missing_account',['电影'],date='2026-11-18',amount='39',kind='expense',category='Entertainment',account=None)
add('录一笔现金收入300元，是叔叔给的生日礼金，日期先不填。','missing_date',['礼金','生日'],amount='300',kind='income',category='Gift',account='Cash')
add('今天给公交卡充值1,200元，银行卡付款，记交通支出。','invalid_amount_separator',['公交','充值'],date='2026-11-18',kind='expense',category='Transport',account='Bank Card')
add('记录一下：今天买橡皮花了2.345元现金，购物支出。','invalid_amount_precision',['橡皮'],date='2026-11-18',kind='expense',category='Shopping',account='Cash')
add('今天午饭总共花了28元，不是收入，是用现金付的餐饮支出。','negated_kind',['午饭'],date='2026-11-18',amount='28',kind='expense',category='Food & Drinks',account='Cash')
add('这笔到账要归奖学金：学校的竞赛奖励已打进银行卡，金额1500元，入账日期就是今天。','scholarship',['竞赛','奖学金','奖励'],date='2026-11-18',amount='1500',kind='income',category='Scholarship',account='Bank Card')
add('今天花了19元买记事本，使用 WeChat 支付，记一笔 shopping 支出。','mixed_language',['记事本'],date='2026-11-18',amount='19',kind='expense',category='Shopping',account='WeChat')
add('查一下我银行卡现在还剩多少钱。','unsupported_balance',clarify=True)
add('今天午饭现金18元，晚饭微信32元，分别记两笔。','multiple_records',clarify=True)
add('支付宝给物业转600元，现在就转过去。','unsupported_execution',clarify=True)

section('finance','en')
add('Log today’s 52-yuan museum admission as entertainment, paid in cash.','ordinary_complete',['museum','admission'],date='2026-11-18',amount='52',kind='expense',category='Entertainment',account='Cash')
add('Record yesterday’s tram fare: CNY 4, paid with my bank card, transport expense.','relative_past',['tram'],date='2026-11-17',amount='4',kind='expense',category='Transport',account='Bank Card')
add('Income entry for 2026-11-12: 720 yuan from my part-time tutoring job, received through WeChat.','ordinary_income',['tutoring','part-time'],date='2026-11-12',amount='720',kind='income',category='Part-time Job',account='WeChat')
add('Bought a thermos today for 87.90 yuan with a credit card. Log it under Shopping.','ordinary_complete',['thermos'],date='2026-11-18',amount='87.90',kind='expense',category='Shopping',account='Credit Card')
add('Record today’s internet bill as an expense from my bank card. Leave the amount blank for now.','missing_amount',['internet'],date='2026-11-18',kind='expense',category='Bills',account='Bank Card')
add('A finance entry: I spent 33 yuan on soup today, but I cannot recall the payment account.','missing_account',['soup'],date='2026-11-18',amount='33',kind='expense',category='Food & Drinks')
add('Record a birthday gift of 220 yuan received in cash; I do not know the transaction date.','missing_date',['birthday','gift'],amount='220',kind='income',category='Gift',account='Cash')
add('Today I paid minus 8 yuan cash for a notebook. Enter a Shopping expense.','invalid_negative_amount',['notebook'],date='2026-11-18',kind='expense',category='Shopping',account='Cash')
add('Add today’s coffee purchase for twenty-six yuan via Alipay, category Food & Drinks.','written_amount',['coffee'],date='2026-11-18',kind='expense',category='Food & Drinks',account='Alipay')
add('Not an expense: a 95-yuan cash gift came in today. Please record the income.','negated_kind',['gift'],date='2026-11-18',amount='95',kind='income',category='Gift',account='Cash')
add('Log 180 yuan spent on a replacement keyboard today. Category Shopping. I used a bank card, not cash.','negated_account',['keyboard'],date='2026-11-18',amount='180',kind='expense',category='Shopping',account='Bank Card')
add('Please record a 61-yuan cash expense for a haircut today, category Others.','explicit_other_category',['haircut'],date='2026-11-18',amount='61',kind='expense',category='Others',account='Cash')
add('Correct my last grocery transaction from 48 yuan to 43 yuan.','unsupported_mutation',clarify=True)
add('Add a bus fare of 5 yuan and separately a bakery purchase of 21 yuan, both today in cash.','multiple_records',clarify=True)
add('I never bought the 260-yuan desk lamp; the payment was rejected. Record a purchase anyway.','denied_transaction',clarify=True)

section('schedule','zh')
add('日历新建：11月21日14:30参加陶艺体验课。','ordinary_complete',['陶艺'],date='2026-11-21',time='14:30')
add('给我安排一个明天的活动：去展览馆听讲座，时间待定。','missing_time',['讲座','展览馆'],date='2026-11-19')
add('本周二下午三点有消防演练，把它补到日程里。','this_week_past',['消防'],date='2026-11-17',time='15:00')
add('下周四上午九点半，实验楼安全培训，加入日历。','next_weekday',['安全培训'],date='2026-11-26',time='09:30')
add('日程里记一个羽毛球友谊赛，哪天还没有确定。','missing_date',['羽毛球'])
add('周日中午十二点与表姐吃饭，加进日程。','noon',['表姐'],date='2026-11-22',time='12:00')
add('新建活动：12月31日23:15在广场看跨年灯光秀。','explicit_month_day',['灯光秀'],date='2026-12-31',time='23:15')
add('把“Friday 摄影展”加入明天上午十点的日程。','quoted_date',['摄影展'],date='2026-11-19',time='10:00')
add('明天下午二点四十五分去牙科复查，新增日程。','written_clock',['牙科'],date='2026-11-19',time='14:45')
add('安排明天的读书会，时间写25:10，稍后我再核对。','invalid_clock',['读书会'],date='2026-11-19',time=None)
add('新建日程：三天后上午八点参观水处理厂。','written_relative',['水处理厂'],date='2026-11-21',time='08:00')
add('明天或后天，下午四点去排练合唱，日期还在商量，先做日程草稿。','ambiguous_date',['合唱'],date=None,time='16:00')
add('把日历里周六的体检取消掉。','unsupported_mutation',clarify=True)
add('日程加两个：明天八点游泳，后天六点瑜伽。','multiple_records',clarify=True)
add('看看明天下午有没有空档可以放个会议。','unsupported_query',clarify=True)

section('schedule','en')
add('Calendar entry: orchestra rehearsal on November 27 at 6:20 pm.','ordinary_complete',['orchestra','rehearsal'],date='2026-11-27',time='18:20')
add('Put a botanical garden visit on my calendar for tomorrow. The start time is undecided.','missing_time',['botanical'],date='2026-11-19')
add('Add the tenant meeting that was this Monday at 10 am to my calendar.','this_week_past',['tenant'],date='2026-11-16',time='10:00')
add('Schedule a ceramics studio induction next Tuesday at 2 pm.','next_weekday',['ceramics','induction'],date='2026-11-24',time='14:00')
add('Create a calendar draft for the alumni picnic at 11:30 am; the date is still undecided.','missing_date',['alumni','picnic'],time='11:30')
add('Book a calendar event for the astronomy livestream at midnight on November 22.','midnight',['astronomy'],date='2026-11-22',time='00:00')
add('Add "Tomorrow Festival" to the calendar on December 5 at 19:00.','quoted_date',['Festival'],date='2026-12-05',time='19:00')
add('Calendar: costume fitting today at 09:15.','timezone_date_boundary',['costume'],date='2026-11-17',time='09:15',now='2026-11-18T06:30:00+00:00')
add('A calender entry for tomorrow at 4 pm: apartment key handover.','typo',['key','handover'],date='2026-11-19',time='16:00')
add('Schedule the volunteer orientation for tomorrow at 18:75. I need to check that time.','invalid_clock',['orientation'],date='2026-11-19',time=None)
add('Add a birdwatching walk in 4 days, starting at 7 am.','numeric_relative',['birdwatching'],date='2026-11-22',time='07:00')
add('Create a calendar draft for a cello lesson at 5 pm, either Friday or Saturday, not decided yet.','ambiguous_date',['cello'],time='17:00')
add('Show all the appointments I booked for next weekend.','unsupported_query',clarify=True)
add('Two separate calendar items, please: a ferry departure tomorrow at 8 am, then a parent-teacher conference the day after tomorrow at 3 pm.','multiple_records',clarify=True)
add('Reschedule the event named "Lab tour" from Thursday to Friday.','unsupported_mutation',clarify=True)

section('health','zh')
add('我又刷手机刷过头了，打开健康页面，看看今天用了多久。','ordinary_usage')
add('想知道这周哪些应用占了我最多的手机时间。','weekly_ranking')
add('帮我看看本机今天的屏幕使用时长，不要给我安排运动。','negated_other_action')
add('进 Health，我想查一下手机使用的周统计。','mixed_language')
add('今天一整天花了多少时间在这部手机的应用上？','daily_total')
add('我想对比本周每天的用机时长，带我去对应页面。','weekly_daily_bars')
add('切到健康模块，显示各个 app 在本机的使用情况。','app_breakdown')
add('用机时间是不是太长了？先打开使用时长统计给我看。','colloquial')
add('今天屏幕使甪时间在哪里看，帮我进入那个页面。','typo')
add('看看这台手机的应用使用排行榜就行，不用记录支出。','negated_finance')
add('能展示这周的屏幕时间吗，我想自己检查一下用机习惯。','weekly_usage')
add('现在打开数字健康，我需要查看今天每个软件的使用时间。','navigation')
add('健康里记一下：今天血压120/80。','unsupported_health_logging',clarify=True)
add('我弟手机今天玩游戏多久，直接帮我查一下他的。','other_person_device',clarify=True)
add('打开用机统计，再帮我新建一个明天跑步的备忘。','cross_module',clarify=True)

section('health','en')
add('Take me to Health so I can inspect my phone use over the current week.','ordinary_usage')
add('Which apps have taken up the largest share of my screen time today on this device?','daily_ranking')
add('I only want this phone’s usage report, not a reminder to exercise.','negated_other_action')
add('Open the app-usage breakdown for this week, please.','weekly_breakdown')
add('How long have I spent using apps on this handset today?','daily_total')
add('Let me compare the daily screen-time totals across this week.','weekly_daily_bars')
add('Go to Health and show the time spent in each application.','app_breakdown')
add('I lost track while scrolling. Can I see today’s phone-usage stats?','colloquial')
add('Where can I check my screeen time for today? Open that page.','typo')
add('Show my on-device app usage, and do not create a finance entry.','negated_finance')
add('Bring up the current week’s phone-use statistics in the health section.','weekly_usage')
add('Can you navigate to the screen that lists how long I use each app on this phone?','navigation')
add('Add 7 hours of sleep to my health log for last night.','unsupported_health_logging',clarify=True)
add('Block short-video apps automatically after thirty minutes each day.','unsupported_device_control',clarify=True)
add('Check my screen time today and schedule a dentist visit for Friday.','cross_module',clarify=True)

assert len(cases) == 120 and len({c['id'] for c in cases}) == 120
assert Counter((c['group'],c['language']) for c in cases) == Counter({(g,l):15 for g in ('memo','finance','schedule','health') for l in ('zh','en')})
assert Counter(c['expected']['status'] for c in cases) == {'draft':96,'clarification':24}
random.Random(20261004).shuffle(cases)
target = OUT / 'cases.json'
if (OUT/'protocol.json').exists(): raise SystemExit('Already frozen; do not overwrite inputs')
target.write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Authored 120 inputs; no application code or model has been invoked.')
