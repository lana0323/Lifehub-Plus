"""Frozen first-pass scorer. Uses unchanged application evaluation helpers."""
import hashlib
import json
import sys
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts/mobile-evaluation'))
from score_holdout import frozen_score, raw_route, summarize, write_csv
OUT=ROOT/'outputs/lifehub-unseen-holdout-v5'
PRIVATE=ROOT/'.local/unseen-holdout-v5'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def verify():
    p=json.loads((OUT/'protocol.json').read_text(encoding='utf-8'))
    assert sha(OUT/'protocol.json')==(OUT/'protocol.sha256').read_text().split()[0]
    for path,digest in p['sourceSha256'].items():
        assert sha(ROOT/path)==digest, f'Frozen source changed: {path}'
    assert sha(OUT/'cases.json')==p['datasetSha256']
    for path,digest in p['preservedRegressionSha256'].items():
        assert sha(ROOT/path)==digest, f'Existing regression changed: {path}'
    return p

def fraction(v):
    if not v['total']: return 'N/A'
    percent=(Decimal(v['passed'])*100/v['total']).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
    return f"{v['passed']}/{v['total']} ({percent}%)"

def main():
    protocol=verify()
    if '--verify' in sys.argv:
        print('Frozen cases, source, scorer and prior regression verified.');return
    if (OUT/'results.json').exists(): raise ValueError('First-pass report already exists; do not overwrite')
    cases=json.loads((OUT/'cases.json').read_text(encoding='utf-8'))
    captured=json.loads((PRIVATE/'validated.json').read_text(encoding='utf-8'))
    assert len(cases)==len(captured)==120
    assert [c['id'] for c in cases]==[r['id'] for r in captured]
    rows={}
    for case,original in zip(cases,captured):
        row={k:v for k,v in original.items() if k!='latencyMs'}
        checks=frozen_score(case,row.get('actual',{}),decimal_amounts=True)
        if 'error' in row: checks={k:False for k in case['expected']}
        row.update(checks=checks,routeCorrect=checks['status'] and checks['module'],allChecksCorrect=all(checks.values()),modelInvoked='raw' in row or 'error' in row)
        row['rawRoute']=raw_route(row) if row['modelInvoked'] else None
        row['rawRouteCorrect']=row['rawRoute']=={k:case['expected'][k] for k in ('status','module')} if row['modelInvoked'] else None
        rows[case['id']]=row
    report=dict(model=protocol['model'],runtime=protocol['runtime'],completedAtUtc=datetime.now(timezone.utc).isoformat(),
        datasetSha256=protocol['datasetSha256'],datasetRole=protocol['datasetRole'],execution=protocol['execution'],complete=True,
        summary=summarize(cases,rows),byLanguage={l:summarize([c for c in cases if c['language']==l],rows) for l in ('zh','en')},
        byWorkflow={g:summarize([c for c in cases if c['group']==g],rows) for g in ('memo','finance','schedule','health')},
        byTag={t:summarize([c for c in cases if t in c['tags']],rows) for t in sorted({t for c in cases for t in c['tags']})},results=list(rows.values()))
    (OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    write_csv(OUT/'results.csv',cases,rows)
    for lang,name in [('zh','chinese-60.csv'),('en','english-60.csv')]:write_csv(OUT/name,[c for c in cases if c['language']==lang],rows)
    failed=[c for c in cases if not rows[c['id']]['allChecksCorrect']]
    write_csv(OUT/'failures.csv',failed,rows)
    s=report['summary']
    lines=['# Lifehub Plus 1.1.3 unseen holdout', '',
        'First pass on 120 newly authored inputs: 60 Chinese and 60 English, 15 per workflow per language. The existing 240-case regression suite was preserved and was not rerun or combined with this score.', '',
        'The inputs, expected answers, scoring code, model configuration and production source hashes were frozen before preparation or inference. One attempt per input, fresh conversation, no retries, no prompt/rule edits, and no result-driven changes to expected answers. Errors stay in the denominator.', '',
        'This holdout was authored internally by the same development assistant. Available prior fixtures were checked for exact and lexical overlap before freezing. It was not used for application tuning before this first pass; it is not an independently collected benchmark, and unseen here does not mean absent from model pretraining.', '',
        '## Results', '', '| Metric | First pass |', '|---|---|']
    for key,label in [('routing','Final pipeline routing'),('requiredFields','Required fields (micro average)'),('allSpecifiedFields','All annotated checks per input'),('supportedDraft','Supported draft checks'),('clarification','Expected clarification handling'),('dates','Date fields, including annotated blanks'),('rawModelRouting','Raw model routing, invoked subset only')]:
        lines.append(f'| {label} | {fraction(s[key])} |')
    lines+=['','| Language | Routing | Required fields | All checks |','|---|---|---|---|']
    for l,name in [('zh','Chinese'),('en','English')]:
        r=report['byLanguage'][l];lines.append(f"| {name} | {fraction(r['routing'])} | {fraction(r['requiredFields'])} | {fraction(r['allSpecifiedFields'])} |")
    lines+=['','| Workflow | Routing | All checks |','|---|---|---|']
    for g,r in report['byWorkflow'].items():lines.append(f"| {g.title()} | {fraction(r['routing'])} | {fraction(r['allSpecifiedFields'])} |")
    lines+=['','## Interpretation','',
        '- Qwen2.5-1.5B-Instruct int8 ekv4096, LiteRT-LM 0.10.2 on Windows CPU. The model, prompt, Unicode-safe transport and Python adapter are shared with the mobile implementation. No latency statistics are reported.',
        '- The final pipeline includes deterministic application rules. Raw model routing is reported separately and excludes inputs handled before model invocation.',
        '- 96 requests are expected to produce reviewable drafts and 24 to require clarification. An annotated blank is correct when information is missing, ambiguous or invalid. A correctly incomplete draft still needs user input before saving.',
        '- Titles use frozen keyword alternatives, so passing is not proof of perfect wording or full semantic equivalence. Field checks cover only annotated fields.',
        '- These scores measure draft preparation and validation. They do not measure Android inference, user confirmation, database writes, or real Health usage-duration accuracy. No new device/reliability checks were run.',
        f"- {s['modelCalls']} model invocations, {s['preflight']} preflight responses, {s['errors']} pipeline errors, {s['unsafeDrafts']} expected-clarification requests returned as drafts. All 120 inputs remain accounted for.",
        '- Once these results are used to modify the application, this set becomes additional regression material and must not be presented as another unseen first pass.',
        '', '## Failed cases', '', '| ID | Input | Failed checks |', '|---|---|---|']
    for c in failed:
        r=rows[c['id']]
        lines.append('| '+c['id']+' | '+c['text'].replace('|','\\|')+' | '+', '.join(k for k,v in r['checks'].items() if not v)+((' (error: '+r['error']+')') if 'error' in r else '')+' |')
    lines+=['','## Local evidence','',
        '[All rows](results.csv) · [Chinese 60](chinese-60.csv) · [English 60](english-60.csv) · [Failures](failures.csv) · [Captured model outputs and checks](results.json) · [Frozen cases](cases.json) · [Protocol](protocol.json) · [Input audit](input-audit.json)', '',
        'This evaluation has not been published to GitHub. The local freeze archive contains the cases, protocol, scoring code and application source snapshot, excluding model weights and runtime binaries. The protocol records their hashes.', '']
    (OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(s,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
