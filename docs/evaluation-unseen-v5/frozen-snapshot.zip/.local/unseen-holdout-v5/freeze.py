"""Freeze before any app preparation or inference; no network or app imports."""
import hashlib
import json
import subprocess
import zipfile
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/lifehub-unseen-holdout-v5'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
assert not (OUT/'protocol.json').exists(), 'Do not replace a frozen protocol'
assert not (ROOT/'.local/unseen-holdout-v5/prepared.json').exists(), 'Preparation already performed'
audit=json.loads((OUT/'input-audit.json').read_text(encoding='utf-8'))
assert not audit['aboveThreshold'] and audit['exactDuplicates']==0
previous=json.loads((ROOT/'docs/evaluation-mobile-v4-regression/protocol.json').read_text(encoding='utf-8'))
source=set(previous['sourceSha256'])
source.update(str(p.relative_to(ROOT).as_posix()) for p in (ROOT/'app/src/main/python').glob('*.py'))
source.update(['.local/unseen-holdout-v5/author_cases.py','.local/unseen-holdout-v5/check_inputs.py','.local/unseen-holdout-v5/score.py','.local/unseen-holdout-v5/freeze.py',
    '.local/unseen-holdout-v5/run.ps1','outputs/lifehub-unseen-holdout-v5/input-audit.json','app/build.gradle.kts','scripts/mobile-evaluation/verify_sources.py'])
source={p for p in source if (ROOT/p).is_file()}
clone=ROOT/'.local/publish/Lifehub-Plus'
commit=subprocess.check_output(['git','-c',f'safe.directory={clone.as_posix()}','-C',str(clone),'rev-parse','HEAD'],text=True).strip()
preserve={p.relative_to(ROOT).as_posix():sha(p) for p in (ROOT/'docs/evaluation-mobile-v4-regression').iterdir() if p.is_file()}
preserve['backend/evaluation/mobile_holdout_v4.json']=sha(ROOT/'backend/evaluation/mobile_holdout_v4.json')
preserve['README.md']=sha(ROOT/'README.md')
model=ROOT/'.local/models/mobile-qwen2.5.litertlm'
modelhash=sha(model)
assert modelhash==previous['modelSha256']
protocol=dict(frozenAtUtc=datetime.now(timezone.utc).isoformat(),appVersion='1.1.3',publishedCommit=commit,
    dataset='outputs/lifehub-unseen-holdout-v5/cases.json',datasetSha256=sha(OUT/'cases.json'),
    datasetRole='New internally authored holdout, first pass; not used to tune application code, prompt or rules before this run.',
    provenance='Development assistant authored and reviewed annotations before any application output. Not an external independent assessor. Chinese and English use different concrete activities but share product capabilities and boundary families. Lexical screening is not proof of semantic independence or absence from pretraining.',
    cases=120,languages={'zh':60,'en':60},perWorkflowPerLanguage=15,expectedOutcomes={'draft':96,'clarification':24},shuffleSeed=20261004,
    runtime=previous['runtime'],machine=previous['machine'],machineProvenance='Same host as the preserved regression protocol.',
    model=previous['model'],modelRevision=previous['modelRevision'],modelSha256=modelhash,modelBytes=model.stat().st_size,
    sampling=previous['sampling'],runsPerCase=1,retries=0,concurrency=1,timeoutSecondsPerCase=180,maxOutputCharacters=16000,
    execution='Fresh model generation for every non-preflight request with frozen production rules. Same mobile prompt, Python adapter and asynchronous Unicode-safe transport on Windows JVM CPU. Fresh conversation per input. No retry, manual repair or edits after inference begins.',
    scoring={**previous['scoring'],'supportedDraft':'All annotated checks pass on the 96 expected-draft inputs. Includes correctly incomplete drafts that require user edits. Does not measure Android UI completion or database writes.'},
    primaryMetrics=['routing','requiredFields','allSpecifiedFields'],secondaryMetrics=['supportedDraft','clarification','dates','rawModelRouting'],
    reporting='No latency figures. Every input, native failure and validation error retained. Raw model and final pipeline metrics separate. All results remain local; no GitHub changes.',
    stopRule='Run all 120 once. Do not stop for poor results. Native crash: preserve failing input and continue without retry. Unattributable infrastructure failure: stop and report incomplete.',
    postRunPolicy='Do not change answers or scoring rules based on outputs. Any suspected annotation issue is a separate note; original first-pass counts stay intact. Future tuning using this set changes its role to regression.',
    inputAuditSha256=sha(OUT/'input-audit.json'),sourceSha256={p:sha(ROOT/p) for p in sorted(source)},
    runtimeSha256={p.relative_to(ROOT).as_posix():sha(p) for p in sorted((ROOT/'.local/ondevice-research/jvm-libs').glob('*.jar'))},
    preservedRegressionSha256=preserve)
(OUT/'protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'protocol.sha256').write_text(sha(OUT/'protocol.json')+'  protocol.json\n',encoding='ascii')
archive=OUT/'frozen-snapshot.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(source|{'outputs/lifehub-unseen-holdout-v5/cases.json','outputs/lifehub-unseen-holdout-v5/protocol.json','outputs/lifehub-unseen-holdout-v5/protocol.sha256'}):z.write(ROOT/p,p)
(OUT/'frozen-snapshot.sha256').write_text(sha(archive)+'  frozen-snapshot.zip\n',encoding='ascii')
print(json.dumps({'frozenAtUtc':protocol['frozenAtUtc'],'datasetSha256':protocol['datasetSha256'],'protocolSha256':sha(OUT/'protocol.json'),'sourceFiles':len(source),'publishedCommit':commit},indent=2))
