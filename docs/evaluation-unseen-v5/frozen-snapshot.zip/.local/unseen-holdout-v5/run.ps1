$ErrorActionPreference='Stop'
$root=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Push-Location $root
try {
    $env:PYTHONIOENCODING='utf-8'
    $env:PYTHONPATH="$root/.local/mobile-python-runtime"
    $env:PYTHONTZPATH="$root/.local/mobile-python-runtime/tzdata/zoneinfo"
    $python='D:/applications/Anaconda/python.exe'
    $javaHome='D:/applications/Android Studio/jbr'
    $run='.local/unseen-holdout-v5'
    $cases='outputs/lifehub-unseen-holdout-v5/cases.json'
    if (Test-Path -LiteralPath "$run/raw.json") { throw 'First-pass output exists; do not rerun' }
    & $python "$run/score.py" --verify
    if ($LASTEXITCODE -ne 0) { throw 'Frozen source verification failed' }
    & "$javaHome/bin/javac.exe" -cp '.local/ondevice-research/jvm-libs/*' -d $run scripts/mobile-evaluation/NativeRunner.java app/src/main/java/com/lifeHub/ai/data/UnicodeSafeMessages.java
    if ($LASTEXITCODE -ne 0) { throw 'Runner compilation failed' }
    & $python scripts/mobile-evaluation/prepare_and_validate.py prepare $cases "$run/prepared.json"
    if ($LASTEXITCODE -ne 0) { throw 'Preparation failed' }
    & $python scripts/mobile-evaluation/supervise_native.py --java "$javaHome/bin/java.exe" --classpath "$run;.local/ondevice-research/jvm-libs/*" --model '.local/models/mobile-qwen2.5.litertlm' --prepared "$run/prepared.json" --raw "$run/raw.json" --cache '.local/ondevice-research' --logs "$run/native-logs"
    if ($LASTEXITCODE -ne 0) { throw 'Inference interrupted; do not discard captured failures' }
    & $python scripts/mobile-evaluation/prepare_and_validate.py validate $cases "$run/validated.json" --raw "$run/raw.json"
    if ($LASTEXITCODE -ne 0) { throw 'Validation failed' }
    & $python "$run/score.py"
    if ($LASTEXITCODE -ne 0) { throw 'Scoring failed' }
} finally { Pop-Location }
