"""Pre-inference schema, label and input-only novelty audit. No app imports."""
import ast
import hashlib
import json
import re
import unicodedata
from collections import Counter
from datetime import datetime, timedelta
from difflib import SequenceMatcher
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/lifehub-unseen-holdout-v5'
cases=json.loads((OUT/'cases.json').read_text(encoding='utf-8'))
normalize=lambda s:re.sub(r'[^\w\u4e00-\u9fff]+','',unicodedata.normalize('NFKC',s).casefold())
old={}
sources=[]
def visit(value, origin):
    if isinstance(value,dict):
        if isinstance(value.get('text'),str):
            old.setdefault(normalize(value['text']),(value.get('id',''),value['text'],origin))
        for item in value.values(): visit(item,origin)
    elif isinstance(value,list):
        for item in value: visit(item,origin)

paths=set((ROOT/'backend/evaluation').glob('*.json'))
paths.update((ROOT/'backend').glob('eval*.json'))
paths.update((ROOT/'app/src/androidTest/assets').glob('*replay*.json'))
for path in sorted(paths):
    try: visit(json.loads(path.read_text(encoding='utf-8-sig')),path.relative_to(ROOT).as_posix())
    except (ValueError,UnicodeError): continue
    sources.append(dict(path=path.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
for path in sorted((ROOT/'backend').glob('test*.py')):
    tree=ast.parse(path.read_text(encoding='utf-8-sig'))
    for node in ast.walk(tree):
        if isinstance(node,ast.Dict):
            for k,v in zip(node.keys,node.values):
                if isinstance(k,ast.Constant) and k.value=='text' and isinstance(v,ast.Constant) and isinstance(v.value,str):
                    visit({'text':v.value},path.relative_to(ROOT).as_posix())
    sources.append(dict(path=path.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))

nearest=[]
for c in cases:
    assert c['module']=='auto'
    assert c['expected']['status'] in ('draft','clarification')
    assert set(c['requiredFields']) <= set(c['expected'])
    local=datetime.fromisoformat(c['now']).astimezone(ZoneInfo(c['timezone']))
    e=c['expected']
    if e['status']=='draft':
        assert e['module']==c['group']
        if c['group']!='health':
            assert e['title']['containsAny'] and all(isinstance(t,str) and t for t in e['title']['containsAny'])
            if e['date']: datetime.strptime(e['date'],'%Y-%m-%d')
        if c['group']=='schedule' and e['time']: datetime.strptime(e['time'],'%H:%M')
    else: assert e['module'] is None and not c['requiredFields']
    n=normalize(c['text'])
    assert n not in old, f'Exact old duplicate: {c["id"]}'
    choices=[(SequenceMatcher(None,n,k,autojunk=False).ratio(),v) for k,v in old.items()]
    score,other=max(choices)
    nearest.append(dict(id=c['id'],similarity=round(score,4),input=c['text'],nearestId=other[0],nearestInput=other[1],source=other[2]))

assert len({normalize(c['text']) for c in cases})==120
# Independent date arithmetic spot checks, without production date parsing.
base=datetime.fromisoformat('2026-11-18T12:00:00+00:00')
assert base.weekday()==2
assert (base-timedelta(days=1)).date().isoformat()=='2026-11-17'
assert (base+timedelta(days=6)).date().isoformat()=='2026-11-24'
assert (base+timedelta(days=8)).date().isoformat()=='2026-11-26'
assert datetime.fromisoformat('2026-11-18T06:30:00+00:00').astimezone(ZoneInfo('America/Los_Angeles')).date().isoformat()=='2026-11-17'
assert datetime.fromisoformat('2026-12-31T16:30:00+00:00').astimezone(ZoneInfo('Asia/Shanghai')).date().isoformat()=='2027-01-01'
report=dict(method='NFKC, casefold and punctuation removal; exact match and character SequenceMatcher against available historical JSON inputs and literal text dictionaries in backend Python tests. No application outputs used.',
    limitations='This is lexical screening, not proof of semantic independence or absence from model pretraining. Product capabilities and boundary families necessarily overlap with regression. Not every historical chat/private input is covered.',
    priorUniqueInputs=len(old),exactDuplicates=0,reviewThreshold=0.78,aboveThreshold=[x for x in nearest if x['similarity']>=.78],
    languages=dict(Counter(c['language'] for c in cases)),outcomes=dict(Counter(c['expected']['status'] for c in cases)),
    tags=dict(Counter(c['tags'][0] for c in cases)),sources=sources,nearestMatches=sorted(nearest,key=lambda x:x['similarity'],reverse=True))
(OUT/'input-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('sources','nearestMatches')},ensure_ascii=False,indent=2))
print('Highest similarities:',json.dumps(report['nearestMatches'][:5],ensure_ascii=False,indent=2))
